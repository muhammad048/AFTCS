function cfg = load_dataset(xlsx, sheet)


    if nargin < 2 || isempty(sheet)
        sheet = 'hetero_delay';
    end
    sheet = lower(char(sheet));


    cfg.sim.time_end = 140;
    cfg.sim.dt       = 0.01;

    cfg.params.lc    = 5;
    cfg.params.hc    = 5;

    cfg.ctrl.alpha   = 3.5;
    cfg.ctrl.beta    = 0.1;
    cfg.ctrl.gamma   = 0.52;

    cfg.carf.V1      = 6.75;
    cfg.carf.V2      = 7.91;
    cfg.carf.C1      = 0.13;
    cfg.carf.C2      = 1.59;


    cfg.leader.profile      = 'paper';
    cfg.leader_v_profile    = cfg.leader.profile;


    cfg.N            = 9;
    cfg.N_followers  = cfg.N;
    cfg.N_total      = cfg.N + 1;


    cfg.init.x       = [0 10 20.5 31.5 43 55 67.5 80.5 94 108]';
    cfg.init.v       = [7 7 7 7 7 7 7 7 7 7]';
    cfg.init.positions  = cfg.init.x;
    cfg.init.velocities = cfg.init.v;

    cfg.desired_gaps = [45 40 35 30 25 20 15 10 5]';


    switch sheet
        case 'no_delay'
            cfg.delays = [0 0 0 0 0 0 0 0 0 0]';

        case 'homo_delay'
            cfg.delays = [0 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2 0.2]';

        case 'hetero_delay'
            cfg.delays = [0 0.15 0.18 0.19 0.20 0.21 0.22 0.23 0.27 0.30]';

        otherwise
            error('Unknown sheet: %s (use no_delay | homo_delay | hetero_delay)', sheet);
    end


    assert(iscolumn(cfg.init.x) && numel(cfg.init.x) == cfg.N + 1, 'init.x must be (N+1)x1');
    assert(iscolumn(cfg.init.v) && numel(cfg.init.v) == cfg.N + 1, 'init.v must be (N+1)x1');
    assert(iscolumn(cfg.desired_gaps) && numel(cfg.desired_gaps) == cfg.N, 'desired_gaps must be Nx1');
    assert(iscolumn(cfg.delays) && numel(cfg.delays) == cfg.N + 1 && cfg.delays(1) == 0, ...
        'delays must be (N+1)x1 with leader first element = 0');


    cfg.scenario = sheet;
end

