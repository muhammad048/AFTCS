
AV Platoon Nonlinear Consensus (dataset-driven) — MATLAB Baseline (Updated)

This folder reproduces Figs. 2–6 of:
"Nonlinear Consensus-Based Connected Vehicle Platoon Control Incorporating Car-Following Interactions and Heterogeneous Time Delays"
using parameters read entirely from Excel datasets.

Structure
---------
- main.m                         : Entry point. Select scenario and run.
- load_dataset.m                 : Reads Excel dataset into a struct `cfg`.
- simulate_platoon.m             : Core simulator implementing Eq. (13) with PLF topology and delays.
- leader_profile.m               : Implements Eq. (52) and disturbance (53).
- compute_metrics.m              : Computes spacing and velocity errors, acceleration.
- plotting/plot_position.m       : Fig. 2
- plotting/plot_spacing_error.m  : Fig. 3
- plotting/plot_velocity.m       : Fig. 4
- plotting/plot_velocity_error.m : Fig. 5
- plotting/plot_acceleration.m   : Fig. 6
- utils/mkdir_run.m              : Creates unique run folder and saves cfg.
- data/platoon_dataset.xlsx      : Example dataset with three sheets: no_delay, hetero_delay, homo_delay.
- output/                        : Each run creates a timestamped subfolder containing PNGs and .mat with results.

How to run
----------
1) Open MATLAB in this folder.
2) In `main.m`, set `scenario` to 'no_delay' | 'hetero_delay' | 'homo_delay' (matches Excel sheet name).
3) Run:  >> main
4) Plots (with insets) and results are saved under ./output/<timestamp>/.

Customize
---------
- To change number of followers, initial positions/velocities, desired gaps, delays, or control/vehicle parameters,
  edit ONLY the Excel file `data/platoon_dataset.xlsx`. No code changes required.
- To add a new scenario, create a new sheet (e.g., `mycase`) with the same column headers; set scenario='mycase'.

Notes
-----
- Discretization: forward Euler with dt from dataset.
- PLF topology: each follower uses predecessor and leader streams.
- Delays are per-follower constants from the dataset. For simplicity, the same delay is used for both leader and predecessor streams per follower in each scenario (consistent with paper’s settings).
- The disturbance ξ_L(t) is enabled from t>=30 s as in Eq. (53).
- Figures are formatted to closely match the paper (fonts, grids, insets).

— Generated automatically.
