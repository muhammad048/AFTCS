function [x_filtered, v_filtered, was_masked] = rbc_filter(cfg, k, dt, sender_idx0, x_rep, v_rep)

[x_filtered, v_filtered, was_masked] = rbc_mark_filter(cfg, k, dt, sender_idx0, x_rep, v_rep);
end
