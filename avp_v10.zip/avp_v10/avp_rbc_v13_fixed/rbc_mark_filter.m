function [x_use, v_use, was_masked] = rbc_mark_filter(cfg, k, dt, sender_idx0, x_rep, v_rep)




N = cfg.N;
veh_idx = sender_idx0 + 1;


RBCTrust.init(N);


if RBCTrust.is_blacklisted(veh_idx)
    x_use = NaN; v_use = NaN; was_masked = true;
    RBCTrust.update(veh_idx, false);
    return;
end



honest_mask = true(N+1,1);
if isfield(cfg,'fault') && isfield(cfg.fault,'ids') && ~isempty(cfg.fault.ids)
    bad = cfg.fault.ids + 1;
    bad = bad(bad>=2 & bad<=N+1);
    honest_mask(bad) = false;
end


f = 0;
if isfield(cfg,'fault') && isfield(cfg.fault,'num_faulty'), f = cfg.fault.num_faulty; end
threshold = (N+1) - f;
eps_x = 2.0;
eps_v = 1.0;
p_corrupt = 0.40;


X = zeros(N+1,1); V = zeros(N+1,1);
for r = 1:N+1
    if honest_mask(r)
        X(r) = x_rep; V(r) = v_rep;
    else
        if rand() < p_corrupt
            X(r) = x_rep + (randn()*5.0);
            V(r) = v_rep + (randn()*2.0);
        else
            X(r) = x_rep; V(r) = v_rep;
        end
    end
end


xm = median(X); vm = median(V);
consistency = (abs(X - xm) <= eps_x) & (abs(V - vm) <= eps_v);
consistent_count = sum(consistency);

if consistent_count >= threshold

    keep = consistency;
    x_use = mean(X(keep));
    v_use = mean(V(keep));
    was_masked = false;
    RBCTrust.update(veh_idx, true);
else

    x_use = NaN; v_use = NaN; was_masked = true;
    RBCTrust.update(veh_idx, false);
end
end
