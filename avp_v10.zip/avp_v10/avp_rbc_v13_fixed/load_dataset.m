
function cfg = load_dataset(xlsx, sheet)

arguments
    xlsx (1,:) char = 'data/platoon_dataset.xlsx'
    sheet (1,:) char = 'hetero_delay'
end

T = readtable(xlsx, 'Sheet', sheet);










req = {'time_end','dt','lc','hc','alpha','beta','gamma','V1','V2','C1','C2','leader_v_profile','N_followers'};
for i=1:numel(req), assert(ismember(req{i}, T.Properties.VariableNames), ['Missing column: ' req{i}]); end

cfg.sim.time_end = T.time_end(1);
cfg.sim.dt       = T.dt(1);
cfg.params.lc    = T.lc(1);
cfg.params.hc    = T.hc(1);
cfg.ctrl.alpha   = T.alpha(1);
cfg.ctrl.beta    = T.beta(1);
cfg.ctrl.gamma   = T.gamma(1);
cfg.carf.V1      = T.V1(1);
cfg.carf.V2      = T.V2(1);
cfg.carf.C1      = T.C1(1);
cfg.carf.C2      = T.C2(1);
cfg.leader.profile = string(T.leader_v_profile(1));
cfg.N            = T.N_followers(1);


vec = @(s) str2num(char(string(s)));

cfg.init.x = vec(T.initial_positions{1})';
cfg.init.v = vec(T.initial_velocities{1})';
cfg.desired_gaps = vec(T.desired_gaps{1})';
cfg.delays = vec(T.delays{1})';


assert(numel(cfg.init.x)==cfg.N+1, 'initial_positions length must be N+1');
assert(numel(cfg.init.v)==cfg.N+1, 'initial_velocities length must be N+1');
assert(numel(cfg.desired_gaps)==cfg.N, 'desired_gaps length must be N');
assert(numel(cfg.delays)==cfg.N+1, 'delays length must be N+1 (leader first element = 0)');

cfg.scenario = sheet;
end
