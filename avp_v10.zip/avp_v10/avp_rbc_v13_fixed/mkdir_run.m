
function out = mkdir_run(p)










    if nargin < 1 || isempty(p)
        p = pwd;
    end


    if isstruct(p)
        cand = {'path','dir','outdir','root','folder','name'};
        s = '';
        for k = 1:numel(cand)
            fn = cand{k};
            if isfield(p, fn)
                val = p.(fn);
                if (ischar(val) && ~isempty(val)) || (isstring(val) && isscalar(val))
                    s = char(val);
                    break;
                end
            end
        end
        if isempty(s)

            s = tempname;
        end
        p = s;
    elseif isstring(p)
        p = char(p);
    elseif iscell(p)
        if ~isempty(p)
            p = char(p{1});
        else
            p = tempname;
        end
    elseif isnumeric(p)
        p = char(string(p));
    elseif ~ischar(p)

        p = tempname;
    end


    if exist('utils.mkdir_run','file')
        try
            utils.mkdir_run(p);
        catch ME
            warning('utils.mkdir_run failed (%s). Falling back to direct mkdir.', ME.message);
            if exist(p, 'dir') ~= 7
                mkdir(p);
            end
        end
    else
        if exist(p, 'dir') ~= 7
            mkdir(p);
        end
    end

    if nargout > 0
        out = p;
    end
end
