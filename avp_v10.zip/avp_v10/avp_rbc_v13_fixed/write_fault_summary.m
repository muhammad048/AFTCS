
function varargout = write_fault_summary(varargin)

try
    if exist('utils.write_fault_summary','file')

        try
            n = nargin('utils.write_fault_summary');
        catch
            n = numel(varargin);
        end
        if n >= 0 && numel(varargin) > n
            args = varargin(1:n);
        else
            args = varargin;
        end
        [varargout{1:nargout}] = feval('utils.write_fault_summary', args{:});
    else

        if strcmp('write_fault_summary','mkdir_run') && ~isempty(varargin)
            p = varargin{1}; if exist(p,'dir')~=7, mkdir(p); end
        else
            [varargout{1:nargout}] = deal([]);
        end
    end
catch ME
    warning('Wrapper write_fault_summary failed: %s', ME.message);
    [varargout{1:nargout}] = deal([]);
end
end
