
function plot_spacing_error(cfg, res, met, outdir, scenario)

t = res.t; se = met.se; N = cfg.N;
figure('Color','w','Position',[100 100 560 420]); hold on; grid on;
for i=1:N, plot(t, se(:,i), 'LineWidth', 1.2); end
xlabel('Time (s)'); ylabel('Spacing error (m)'); title('Spacing error profile');
legend(arrayfun(@(i) sprintf('V%d',i), 1:N, 'UniformOutput', false),'Location','southeast');
saveas(gcf, fullfile(outdir, sprintf('Fig3_spacing_%s.png', scenario)));
close;
end
