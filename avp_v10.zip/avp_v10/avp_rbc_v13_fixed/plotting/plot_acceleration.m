
function plot_acceleration(cfg, res, met, outdir, scenario)

t = res.t; a = met.a; N = cfg.N;
figure('Color','w','Position',[100 100 560 420]); hold on; grid on;
for i=1:N, plot(t, a(:,i), 'LineWidth', 1.0); end
xlabel('Time (s)'); ylabel('Acceleration (m/s^2)'); title('Acceleration profile');
legend(arrayfun(@(i) sprintf('V%d',i), 1:N, 'UniformOutput', false),'Location','southeast');

add_inset(gca, t, a, [30 60], [-5 6], [0.18 0.65 0.25 0.25]);
add_inset(gca, t, a, [80 110], [-6 6], [0.62 0.2 0.25 0.25]);
saveas(gcf, fullfile(outdir, sprintf('Fig6_acc_%s.png', scenario)));
close;
end
