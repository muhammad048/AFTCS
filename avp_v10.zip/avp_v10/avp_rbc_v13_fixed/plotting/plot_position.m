function plot_position(cfg, res, outdir, scenario)


t = res.t;
x = res.x;
N = cfg.N;

figure('Color','w','Position',[100 100 560 420]); hold on; grid on;

for i = 1:N+1
    plot(t, x(:,i), 'LineWidth', 1.2);
end

xlabel('Time (s)'); ylabel('Position (m)'); title('Position profile');
legend(arrayfun(@(i) sprintf('V%d', i-1), 0:N, 'UniformOutput', false), ...
       'Location', 'southeast');


t25idx = max(1, round(25/cfg.sim.dt));
yLo1 = min(x(1,2:end), [], 'all') - 5;
yHi1 = min(x(t25idx,2:end), [], 'all') + 20;

yLo1 = double(yLo1); yHi1 = double(yHi1);
add_inset(gca, t, x, [5 25], [yLo1 yHi1], [0.18 0.65 0.25 0.25]);


t110idx = max(1, round(110/cfg.sim.dt));
yLo2 = max(x(t110idx,2:end), [], 'all') - 30;
yHi2 = max(x(:,2:end), [], 'all') + 10;
yLo2 = double(yLo2); yHi2 = double(yHi2);
add_inset(gca, t, x, [110 130], [yLo2 yHi2], [0.62 0.20 0.25 0.25]);

saveas(gcf, fullfile(outdir, sprintf('Fig2_position_%s.png', scenario)));
close;
end
