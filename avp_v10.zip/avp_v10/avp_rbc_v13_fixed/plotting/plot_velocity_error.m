
function plot_velocity_error(cfg, res, met, outdir, scenario)

t = res.t; ve = met.ve; N = cfg.N;
figure('Color','w','Position',[100 100 560 420]); hold on; grid on;
for i=1:N, plot(t, ve(:,i), 'LineWidth', 1.2); end
xlabel('Time (s)'); ylabel('Velocity error (m/s)'); title('Velocity errors profile');
legend(arrayfun(@(i) sprintf('V%d',i), 1:N, 'UniformOutput', false),'Location','southeast');

add_inset(gca, t, ve, [30 60], [-5 1], [0.18 0.65 0.25 0.25]);
add_inset(gca, t, ve, [80 110], [-1 5], [0.62 0.2 0.25 0.25]);
saveas(gcf, fullfile(outdir, sprintf('Fig5_vel_error_%s.png', scenario)));
close;
end
