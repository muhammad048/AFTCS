function axin = add_inset(parentAx, x, y, xlimRange, ylimRange, pos)


fig = ancestor(parentAx, 'figure');
axin = axes('Parent', fig, 'Position', pos);


xlimRange = xlimRange(:).';
ylimRange = ylimRange(:).';

if numel(xlimRange) ~= 2
    error('add_inset: xlimRange must be a 2-element vector');
end
if numel(ylimRange) ~= 2
    error('add_inset: ylimRange must be a 2-element vector');
end


xlimRange = [xlimRange(1), xlimRange(2)];
ylimRange = [ylimRange(1), ylimRange(2)];

xlimRange = sort(xlimRange);
ylimRange = sort(ylimRange);


if ~isfinite(ylimRange(1)) || ~isfinite(ylimRange(2)) || diff(ylimRange) <= 0

    if isvector(y)
        yseg = y(x >= xlimRange(1) & x <= xlimRange(2));
    else
        yseg = y(x >= xlimRange(1) & x <= xlimRange(2), :);
    end
    if isempty(yseg)
        yseg = y;
    end
    ylo = min(yseg(:));
    yhi = max(yseg(:));
    if ~isfinite(ylo) || ~isfinite(yhi) || yhi <= ylo
        ylo = -1; yhi = 1;
    end
    pad = 0.05*(abs(yhi - ylo) + eps);
    ylimRange = [ylo - pad, yhi + pad];
end


hold(axin, 'on'); grid(axin, 'on'); box(axin, 'on');
plot(axin, x, y, 'LineWidth', 1.2);
xlim(axin, xlimRange);
ylim(axin, ylimRange);
set(axin, 'FontSize', 9);
end
