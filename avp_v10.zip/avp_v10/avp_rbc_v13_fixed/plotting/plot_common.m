
function axin = add_inset(ax, x, y, xr, yr, pos)

axin = axes('Position', pos);
box on; grid on; hold on;
plot(axin, x, y, 'LineWidth', 1.2);
xlim(axin, xr); ylim(axin, yr);
set(axin, 'FontSize', 9);
end
