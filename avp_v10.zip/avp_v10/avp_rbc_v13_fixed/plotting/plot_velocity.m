
function plot_velocity(cfg, res, outdir, scenario)

t = res.t; v = res.v; N = cfg.N;
figure('Color','w','Position',[100 100 560 420]); hold on; grid on;
for i=1:N+1, plot(t, v(:,i), 'LineWidth', 1.2); end
xlabel('Time (s)'); ylabel('Velocity (m/s)'); title('Velocity profile');
legend(arrayfun(@(i) sprintf('V%d',i-1), 0:N, 'UniformOutput', false),'Location','southeast');

add_inset(gca, t, v, [30 60], [6 13], [0.18 0.65 0.25 0.25]);
add_inset(gca, t, v, [80 110], [-1 16], [0.62 0.2 0.25 0.25]);
saveas(gcf, fullfile(outdir, sprintf('Fig4_velocity_%s.png', scenario)));
close;
end
