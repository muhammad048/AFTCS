
function varargout = write_run_log(varargin)

try
    if exist('utils.write_run_log','file')

        try
            n = nargin('utils.write_run_log');
        catch
            n = numel(varargin);
        end
        if n >= 0 && numel(varargin) > n
            args = varargin(1:n);
        else
            args = varargin;
        end
        [varargout{1:nargout}] = feval('utils.write_run_log', args{:});
    else

        if strcmp('write_run_log','mkdir_run') && ~isempty(varargin)
            p = varargin{1}; if exist(p,'dir')~=7, mkdir(p); end
        else
            [varargout{1:nargout}] = deal([]);
        end
    end
catch ME
    warning('Wrapper write_run_log failed: %s', ME.message);
    [varargout{1:nargout}] = deal([]);
end
end
