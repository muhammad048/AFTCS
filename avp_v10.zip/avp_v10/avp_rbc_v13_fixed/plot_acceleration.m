
function varargout = plot_acceleration(varargin)

try
    if exist('plotting.plot_acceleration','file')

        try
            n = nargin('plotting.plot_acceleration');
        catch
            n = numel(varargin);
        end
        if n >= 0 && numel(varargin) > n
            args = varargin(1:n);
        else
            args = varargin;
        end
        [varargout{1:nargout}] = feval('plotting.plot_acceleration', args{:});
    else

        if strcmp('plot_acceleration','mkdir_run') && ~isempty(varargin)
            p = varargin{1}; if exist(p,'dir')~=7, mkdir(p); end
        else
            [varargout{1:nargout}] = deal([]);
        end
    end
catch ME
    warning('Wrapper plot_acceleration failed: %s', ME.message);
    [varargout{1:nargout}] = deal([]);
end
end
