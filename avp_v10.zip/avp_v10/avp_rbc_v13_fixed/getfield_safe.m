
function v = getfield_safe(s, field, default)




    if nargin < 3
        default = [];
    end

    try
        if isstruct(s) && isfield(s, field)
            v = s.(field);
        else
            v = default;
        end
    catch
        v = default;
    end
end
