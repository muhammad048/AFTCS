function write_fault_summary(logs, outdir, cases)


fname = fullfile(outdir, 'summary.txt');
fid = fopen(fname, 'w');
fprintf(fid, 'Fault tolerance summary\n');
fprintf(fid, '=======================\n\n');

for c = 1:length(cases)
    tag = cases{c};
    log = logs{c};
    avg_mask = mean(log.masked_msgs ./ max(log.faulty_msgs,1));
    final_agree = log.final_agreement;
    t95 = log.time_to_95;
    fprintf(fid, 'Case %s:\n', tag);
    fprintf(fid, '  Avg masking rate: %.2f %%\n', avg_mask*100);
    fprintf(fid, '  Final agreement: %.2f %%\n', final_agree*100);
    fprintf(fid, '  Time to 95%% agreement: %.2f s\n\n', t95);
end

fclose(fid);
end
