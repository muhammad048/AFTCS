function write_run_log(run_dir,nFaulty,scenario,hist,rbc_status,metrics)


logfile = fullfile(run_dir,'log.txt');
fid = fopen(logfile,'w');
if fid==-1, warning('Could not open log file'); return; end

fprintf(fid,'=== Simulation Run Log ===\n');
fprintf(fid,'Scenario: %s\n', scenario);
fprintf(fid,'Case: %d faulty nodes\n', nFaulty);

if isfield(hist,'faulty_idx')
    fprintf(fid,'Faulty IDs: %s\n', mat2str(hist.faulty_idx));
else
    fprintf(fid,'Faulty IDs: N/A\n');
end

if isfield(hist,'cfg') && isfield(hist.cfg,'fault')
    fprintf(fid,'Fault start time: %.1f s\n', hist.cfg.fault.start_time);
end

fprintf(fid,'RBC filter: %s\n', rbc_status);

if exist('metrics','var') && ~isempty(metrics)
    if isfield(metrics,'consensus_validity')
        fprintf(fid,'Consensus validity: %.2f%%%%\n', metrics.consensus_validity*100);
    end
    if isfield(metrics,'fault_masking_rate')
        fprintf(fid,'Fault masking rate: %.2f%%%%\n', metrics.fault_masking_rate*100);
    end
end

fprintf(fid,'Notes: Run completed successfully.\n');
fclose(fid);
end
