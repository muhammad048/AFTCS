function plot_consensus_validity(log, cfg, outdir, tag)



t = log.t(:)';
L = log.leader_idx;         
Hmask = log.honest_mask(:);
Hmask(L) = false;           
Hidx = find(Hmask);

x = log.x;
v = log.v;
nT = numel(t);
nH = numel(Hidx);
lc = log.lc; hc = log.hc;

xL = x(L,:);
vL = v(L,:);
xt = zeros(nH,nT); vt = zeros(nH,nT);
for k = 1:nH
    i = Hidx(k);
    xt(k,:) = (xL - x(i,:) - k*(lc+hc));
    vt(k,:) = (v(i,:) - vL);
end

ev = cfg.eps_v; ex = cfg.eps_x;

med_v = median(v(Hidx,:),1);
agree = zeros(1,nT);
for tix = 1:nT
    band_v = abs(v(Hidx,tix) - med_v(tix)) <= ev;
    band_x = abs(xt(:,tix)) <= ex;
    agree(tix) = sum(band_v(:) & band_x(:)) / nH;
end

xnorm = vecnorm(xt,2,1);
vnorm = vecnorm(vt,2,1);

figure('Color','w');
yyaxis left;  plot(log.t, agree, 'LineWidth',2); ylim([0 1.02]); ylabel('Agreement (fraction)');
yline(0.95,'--','Target 95%','HandleVisibility','off');

yyaxis right; plot(log.t, xnorm, 'LineWidth',1); hold on; plot(log.t, vnorm, 'LineWidth',1);
ylabel('||x~||_2, ||v~||_2');
xlabel('Time (s)');
title(sprintf('Consensus validity (%s)', tag));
legend('Agreement','||x~||_2','||v~||_2','Location','northeast');
grid on;

if ~exist(outdir,'dir'), mkdir(outdir); end
saveas(gcf, fullfile(outdir, sprintf('consensus_validity_%s.png', tag)));
close(gcf);
end
