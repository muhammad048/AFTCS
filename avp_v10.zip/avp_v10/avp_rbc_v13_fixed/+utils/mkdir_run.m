function mkdir_run(p)

if exist(p,'dir')~=7
    mkdir(p);
end
end
