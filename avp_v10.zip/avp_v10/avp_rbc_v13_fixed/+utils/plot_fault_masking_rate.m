function plot_fault_masking_rate(log, cfg, outdir, tag)



t   = log.t(:);
M   = log.masked_msgs(:);
F   = max(log.faulty_msgs(:),1);

inst = M ./ F;


N = max(1, round(cfg.win_s/cfg.dt));
kern = ones(N,1)/N;
roll = filter(kern,1,inst);
roll(1:N-1) = inst(1:N-1);

figure('Color','w'); 
plot(t, inst, 'LineWidth',0.8); hold on;
plot(t, roll, 'LineWidth',2);
yline(0.95,'--','Target 95%','HandleVisibility','off');
xlabel('Time (s)'); ylabel('Masking rate');
title(sprintf('Fault masking rate (%s)', tag));
legend('instantaneous','rolling','Location','southeast');
ylim([0 1.02]);
grid on;

if ~exist(outdir,'dir'), mkdir(outdir); end
saveas(gcf, fullfile(outdir, sprintf('masking_rate_%s.png', tag)));
close(gcf);
end
