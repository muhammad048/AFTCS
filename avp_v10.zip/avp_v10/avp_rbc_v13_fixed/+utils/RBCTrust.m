classdef RBCTrust

    
    methods(Static)
        function state = init(N)
            persistent trust_state
            if isempty(trust_state)
                trust_state.N = N;
                trust_state.strikes = zeros(N+1,1);
                trust_state.blacklist = false(N+1,1);
                trust_state.accept_rate = zeros(N+1,1);
                trust_state.attempts = zeros(N+1,1);
            end
            state = trust_state;
        end
        
        function update(sender_idx, accepted)
            persistent trust_state
            if isempty(trust_state); return; end
            trust_state.attempts(sender_idx) = trust_state.attempts(sender_idx) + 1;
            if ~accepted
                trust_state.strikes(sender_idx) = trust_state.strikes(sender_idx) + 1;
            else
                trust_state.accept_rate(sender_idx) = trust_state.accept_rate(sender_idx) + 1;
            end

            if trust_state.strikes(sender_idx) >= 5
                trust_state.blacklist(sender_idx) = true;
            end
        end
        
        function tf = is_blacklisted(sender_idx)
            persistent trust_state
            if isempty(trust_state); tf = false; return; end
            tf = trust_state.blacklist(sender_idx);
        end
        
        function trust = get()
            persistent trust_state
            if isempty(trust_state); trust = []; else; trust = trust_state; end
        end
    end
end
