
function active = fault_active(cfg, k)

t = (k-1) * cfg.sim.dt;
active = isfield(cfg,'fault') && cfg.fault.enable && (t >= cfg.fault.start_time) ...
         && isfield(cfg.fault,'num_faulty') && (cfg.fault.num_faulty > 0);
end

function isF = is_faulty_follower(cfg, follower_idx1based)

isF = false;
if ~isfield(cfg,'fault') || ~cfg.fault.enable || cfg.fault.num_faulty==0
    return;
end
if ~isfield(cfg.fault,'ids') || isempty(cfg.fault.ids)
    return;
end
isF = any(cfg.fault.ids == follower_idx1based);
end

function [x_rep, v_rep] = fault_report_random(cfg, k, sender_idx0based, x_true, v_true)






x_rep = x_true; v_rep = v_true;

if ~fault_active(cfg, k), return; end
if sender_idx0based==0, return; end
if ~is_faulty_follower(cfg, sender_idx0based), return; end


if ~isfield(cfg,'fault') || ~isfield(cfg.fault,'params'), cfg.fault.params = struct(); end
p = cfg.fault.params;
fields = {'sigma_x','sigma_v','p_fullrand','v_min','v_max','x_span'};
defaults = [50.0,       5.0,     0.25,        0.0,    40.0,   300.0];
for ii=1:numel(fields)
    f = fields{ii};
    if ~isfield(p, f), p.(f) = defaults(ii); end
end
cfg.fault.params = p;


if rand < p.p_fullrand

    v_rep = p.v_min + (p.v_max - p.v_min) * rand(size(v_true));
    x_rep = x_true + (rand(size(x_true)) - 0.5) * 2 * p.x_span;
else

    v_rep = v_true + p.sigma_v * randn(size(v_true));
    x_rep = x_true + p.sigma_x * randn(size(x_true));

    v_rep = max(v_rep, p.v_min);
end
end
