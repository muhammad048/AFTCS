classdef FaultUtils


    methods(Static)
        function active = fault_active(cfg, k, dt)
            active = false;
            if ~isfield(cfg,'fault') || ~isfield(cfg.fault,'enable') || ~cfg.fault.enable
                return;
            end
            t = (k-1) * dt;
            t0 = 30;
            if isfield(cfg.fault,'start_time'), t0 = cfg.fault.start_time; end
            active = (t >= t0);
        end

        function tf = is_faulty_follower(cfg, idx0)
            tf = false;
            if ~isfield(cfg,'fault') || ~isfield(cfg.fault,'ids') || isempty(cfg.fault.ids)
                return;
            end
            tf = any(cfg.fault.ids == idx0);
        end

        function [x_rep, v_rep, was_fault] = fault_report_random(cfg, k, sender_idx0, x_true, v_true)
            x_rep = x_true; v_rep = v_true; was_fault = false;
            if sender_idx0 == 0, return; end

            p = FaultUtils.default_params(cfg);

            if rand < p.p_fullrand
                v_rep = p.v_min + (p.v_max - p.v_min) * rand();
                x_rep = x_true + (rand() - 0.5) * 2 * p.x_span;
            else
                v_rep = v_true + p.sigma_v * randn();
                x_rep = x_true + p.sigma_x * randn();
            end
            v_rep = max(v_rep, p.v_min);
            was_fault = true;
        end

        function [x_use, v_use, was_masked] = mask_plausibility(cfg, k, recv_idx0, sender_idx0, x_rep, v_rep, x_recv_prev, v_recv_prev)
            p = FaultUtils.default_params(cfg);
            lc = cfg.params.lc;

            was_masked = false; x_use = x_rep; v_use = v_rep;

            if ~isfinite(v_rep) || v_rep < p.v_min || v_rep > p.v_max
                was_masked = true;
            end

            min_gap = lc;
            if x_rep < x_recv_prev + min_gap/2
                was_masked = true;
            end

            if abs(v_rep - v_recv_prev) > 3 * max(1, p.sigma_v)
                was_masked = true;
            end

            if was_masked
                v_use = min(max(v_rep, p.v_min), p.v_max);
                x_use = max(x_rep, x_recv_prev + min_gap);
            end
        end

        function p = default_params(cfg)
            p = struct('p_fullrand',0.35,'v_min',0.0,'v_max',40.0,'x_span',50.0,'sigma_v',2.0,'sigma_x',5.0);
            if isfield(cfg,'fault') && isfield(cfg.fault,'params') && ~isempty(cfg.fault.params)
                user = cfg.fault.params;
                f = fieldnames(p);
                for i=1:numel(f)
                    if isfield(user,f{i}) && ~isempty(user.(f{i})), p.(f{i}) = user.(f{i}); end
                end
            end
        end
    end
end
