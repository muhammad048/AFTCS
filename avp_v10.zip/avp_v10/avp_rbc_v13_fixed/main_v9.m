function main()







clc; close all; clear;


addpath('utils');
addpath('plotting');


xlsxPath     = 'data/platoon_dataset.xlsx';
scenarios    = {'no_delay','homo_delay','hetero_delay'};
faultCases   = [0 1 2 3];
faultStart   = 30.0;
saveMatlabFig = false;


summary_logs  = {};
summary_cases = {};


if ~exist('output','dir'),  mkdir('output');  end
if ~exist('results','dir'), mkdir('results'); end

for fc = 1:numel(faultCases)
    nFaulty = faultCases(fc);

    for s = 1:numel(scenarios)
        scenario = scenarios{s};
        fprintf('\n=== Case: %d faulty | Scenario: %s ===\n', nFaulty, scenario);

        try



            cfg = load_dataset(xlsxPath, scenario);
            cfg.scenario = scenario;




            if ~isfield(cfg,'fault') || ~isstruct(cfg.fault), cfg.fault = struct; end
            cfg.fault.enable     = nFaulty > 0;
            cfg.fault.count      = nFaulty;


            N_guess = guessN(cfg);
            cap10 = max(1, ceil(0.10 * N_guess));
            cfg.fault.num_faulty = min(nFaulty, cfg.N);
            cfg.fault.start_time = faultStart;
            cfg.fault.seed       = 1234 + 100*fc + s;


            if ~isfield(cfg.fault,'params') || ~isstruct(cfg.fault.params), cfg.fault.params = struct; end
            cfg.fault.params = setdefault(cfg.fault.params, 'sigma_x',    50.0);
            cfg.fault.params = setdefault(cfg.fault.params, 'sigma_v',     5.0);
            cfg.fault.params = setdefault(cfg.fault.params, 'p_fullrand',  0.25);
            cfg.fault.params = setdefault(cfg.fault.params, 'v_min',       0.0);
            cfg.fault.params = setdefault(cfg.fault.params, 'v_max',      40.0);
            cfg.fault.params = setdefault(cfg.fault.params, 'x_span',    300.0);


            rng(cfg.fault.seed);
            if cfg.fault.enable && cfg.fault.num_faulty > 0
                ids = sort(randperm(N_guess, cfg.fault.num_faulty));
                cfg.fault.ids = ids;
            else
                cfg.fault.ids = [];
            end




            run_tag = sprintf('case%d_%s', nFaulty, scenario);
            runInfo = mkdir_run(cfg, run_tag);
            outdir  = runInfo.outdir;




            [res, hist] = simulate_platoon_v9(cfg);




            met = compute_metrics(cfg, res);
            safe_plot(@() plot_position(      cfg, res,        outdir, scenario), saveMatlabFig);
            safe_plot(@() plot_spacing_error( cfg, res,  met,  outdir, scenario), saveMatlabFig);
            safe_plot(@() plot_velocity(      cfg, res,        outdir, scenario), saveMatlabFig);
            safe_plot(@() plot_velocity_error(cfg, res,  met,  outdir, scenario), saveMatlabFig);
            safe_plot(@() plot_acceleration(  cfg, res,  met,  outdir, scenario), saveMatlabFig);




            fault_dir = fullfile(outdir, 'fault_tolerance');
            if ~exist(fault_dir, 'dir'), mkdir(fault_dir); end

            logdata = [];
            if isstruct(res) && isfield(res,'log'), logdata = res.log; end
            if isempty(logdata) && exist('hist','var') && isstruct(hist), logdata = hist; end

            if ~isempty(logdata) && isstruct(logdata)

                if isfield(logdata,'t') && numel(logdata.t)>1
                    cfg_plot.dt = logdata.t(2) - logdata.t(1);
                else

                    cfg_plot.dt = get_nested(cfg, {'sim','dt'}, 0.01);
                end
                cfg_plot.win_s = 2.0;
                cfg_plot.eps_v = 0.5;
                cfg_plot.eps_x = 1.0;
                tag = sprintf('f%d_%s', nFaulty, scenario);

                if isfield(logdata,'masked_msgs') && isfield(logdata,'faulty_msgs')
                    safe_plot(@() plot_fault_masking_rate(logdata, cfg_plot, fault_dir, tag), saveMatlabFig);
                end
                if isfield(logdata,'x') && isfield(logdata,'v')
                    safe_plot(@() plot_consensus_validity(logdata, cfg_plot, fault_dir, tag), saveMatlabFig);
                end


                if isfield(logdata,'faulty_msgs') && isfield(logdata,'masked_msgs')
                    final_agree = NaN; t95 = NaN;
                    if isfield(logdata,'agreement') && ~isempty(logdata.agreement)
                        final_agree = logdata.agreement(end);
                        idx95 = find(logdata.agreement >= 0.95, 1, 'first');
                        if ~isempty(idx95)
                            if isfield(logdata,'t') && numel(logdata.t) >= idx95
                                t95 = logdata.t(idx95);
                            else
                                t95 = (idx95-1) * cfg_plot.dt;
                            end
                        end
                    end
                    summary_logs{end+1} = struct( ...
                        'masked_msgs', logdata.masked_msgs, ...
                        'faulty_msgs', logdata.faulty_msgs, ...
                        'final_agreement', final_agree, ...
                        'time_to_95', t95 ...
                    );
                    summary_cases{end+1} = tag;
                end
            else
                warning('No structured logdata available for fault-tolerance plots (case=%d, scenario=%s)', nFaulty, scenario);
            end




            save(fullfile(outdir, 'results.mat'), 'cfg', 'res', 'met', 'hist');
            fprintf('✔ Saved: %s\n', outdir);

        catch ME
            warning('Failed (case=%d, scenario=%s): %s', nFaulty, scenario, ME.message);
        end
    end
end




if ~isempty(summary_logs)
    summary_dir = fullfile('results','fault_tolerance_summary');
    if ~exist(summary_dir,'dir'), mkdir(summary_dir); end
    write_fault_summary(summary_logs, summary_dir, summary_cases);
    fprintf('✔ Wrote summary to %s\n', summary_dir);
end

fprintf('\nAll fault cases and scenarios processed.\n');
end


function s = setdefault(s, key, val)
    if ~isfield(s, key) || isempty(s.(key)), s.(key) = val; end
end

function val = get_nested(s, keys, def)
    val = def;
    try
        cur = s;
        for i = 1:numel(keys)
            if ~isstruct(cur) || ~isfield(cur, keys{i})
                return;
            end
            cur = cur.(keys{i});
        end
        if ~isempty(cur), val = cur; end
    catch
        val = def;
    end
end

function N = guessN(cfg)

    if isfield(cfg,'N') && ~isempty(cfg.N)
        N = cfg.N;
    elseif isfield(cfg,'init') && isfield(cfg.init,'x') && ~isempty(cfg.init.x)
        N = numel(cfg.init.x) - 1;
    else
        N = 9;
    end
end

function safe_plot(fh, saveFigAlso)

    try
        fh();
        if saveFigAlso
            h = gcf;
            if ~isempty(h) && ishghandle(h)
                fpath = get(h, 'FileName');
                if ~isempty(fpath)
                    [p,n,~] = fileparts(fpath);
                    savefig(h, fullfile(p, [n '.fig']));
                end
            end
        end
        drawnow;
    catch ME
        warning('Plot failed: %s', ME.message);
    end
end
