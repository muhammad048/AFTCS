
function [vL, xL] = leader_profile(t, cfg)

vL = zeros(size(t));
for k=1:numel(t)
    tau = t(k);

    if cfg.leader.profile=="paper"
        if tau < 30
            v = 7;
        elseif tau < 70
            v = 7 + 8/(1 + exp(-0.5*tau + 25));
        elseif tau < 80
            v = 15;
        else
            v = 15 - 15/(1 + exp(-0.5*tau + 48));
        end

        if tau >= 30
            xi = 0.3 * sin(2*pi*(tau - 30)) * exp(-(tau-30)/10);
        else
            xi = 0;
        end
        vL(k) = v + xi;
    else

        vL(k) = str2double(cfg.leader.profile);
    end
end

xL = cumtrapz(t, vL) + cfg.init.x(1);
end
