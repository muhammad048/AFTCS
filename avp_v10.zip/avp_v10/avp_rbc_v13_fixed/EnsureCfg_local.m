function cfg = EnsureCfg_local(cfg, scenario)


if nargin < 2 || isempty(scenario)
    scenario = getfield_safe(cfg, 'scenario', 'no_delay');
end
cfg.scenario = scenario;


if ~isfield(cfg, 'params'), cfg.params = struct(); end
if ~isfield(cfg.params, 'hc'), cfg.params.hc = 5; end
if ~isfield(cfg.params, 'lc'), cfg.params.lc = 5; end


if ~isfield(cfg, 'ctrl'), cfg.ctrl = struct(); end
if ~isfield(cfg.ctrl, 'alpha'), cfg.ctrl.alpha = 3.5; end
if ~isfield(cfg.ctrl, 'beta'),  cfg.ctrl.beta  = 0.1; end
if ~isfield(cfg.ctrl, 'gamma'), cfg.ctrl.gamma = 0.52; end


if ~isfield(cfg, 'nonlin'), cfg.nonlin = struct(); end
if ~isfield(cfg.nonlin, 'V1'), cfg.nonlin.V1 = 6.75; end
if ~isfield(cfg.nonlin, 'V2'), cfg.nonlin.V2 = 7.91; end
if ~isfield(cfg.nonlin, 'C1'), cfg.nonlin.C1 = 0.13; end
if ~isfield(cfg.nonlin, 'C2'), cfg.nonlin.C2 = 1.59; end


if ~isfield(cfg, 'sim'), cfg.sim = struct(); end
if ~isfield(cfg.sim, 'dt'),       cfg.sim.dt = 0.01; end
if ~isfield(cfg.sim, 'time_end'), cfg.sim.time_end = 120; end


if ~isfield(cfg, 'init'), cfg.init = struct(); end
if ~isfield(cfg.init, 'x')
    cfg.init.x = [0,10,20.5,31.5,43,55,67.5,80.5,94,108];
end
if ~isfield(cfg.init, 'v')
    cfg.init.v = 7 * ones(1, numel(cfg.init.x));
end
cfg.N = numel(cfg.init.x) - 1;


if ~isfield(cfg, 'delay'), cfg.delay = struct(); end
switch lower(scenario)
    case 'no_delay'
        cfg.delay.type = 'no_delay';
        cfg.delay.tau_homo = 0;
    case 'homo_delay'
        cfg.delay.type = 'homo_delay';
        if ~isfield(cfg.delay, 'tau_homo'), cfg.delay.tau_homo = 0.20; end
    otherwise
        cfg.delay.type = 'hetero_delay';
        if ~isfield(cfg.delay, 'tau_hetero')
            cfg.delay.tau_hetero = [0,0.15,0.18,0.19,0.20,0.21,0.22,0.23,0.27,0.30];
        end
end


if ~isfield(cfg, 'fault'), cfg.fault = struct(); end
nReq = getfield_safe(cfg.fault, 'num_faulty', 0);
cap10 = max(1, ceil(0.10 * cfg.N));
cfg.fault.num_faulty = max(0, min(nReq, cap10));
if ~isfield(cfg.fault, 'start_time'), cfg.fault.start_time = 30; end
end
