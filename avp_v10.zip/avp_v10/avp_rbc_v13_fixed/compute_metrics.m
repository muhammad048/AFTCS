
function met = compute_metrics(cfg, res)

N = cfg.N;
hc = cfg.params.hc;
se = zeros(numel(res.t), N);
for i=2:N+1
    se(:,i-1) = res.x(:,i-1) - res.x(:,i) - hc;
end

ve = res.v(:,2:end) - res.v(:,1);

met.se = se;
met.ve = ve;
met.a  = res.a(:,2:end);
end
