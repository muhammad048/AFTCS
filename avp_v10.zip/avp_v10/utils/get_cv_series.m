function cv = get_cv_series(logdata, res, cfg, cfg_plot, met)















    if isstruct(logdata) && isfield(logdata,'agreement') && ~isempty(logdata.agreement)
        a = logdata.agreement(:);
        if any(~isnan(a) & a ~= 0)
            cv = a;
            return;
        end
    end


    if exist('met','var') && isstruct(met)
        cand = {};
        if isfield(met,'cv'), cand{end+1} = met.cv; end
        if isfield(met,'consensus_validity'), cand{end+1} = met.consensus_validity; end
        if isfield(met,'agreement'), cand{end+1} = met.agreement; end
        for i = 1:numel(cand)
            v = cand{i};
            if ~isempty(v)
                v = v(:);
                if any(~isnan(v) & v ~= 0)
                    cv = v;
                    return;
                end
            end
        end
    end


    eps_x = 1.0; eps_v = 0.5;
    if exist('cfg_plot','var') && isstruct(cfg_plot)
        if isfield(cfg_plot,'eps_x') && ~isempty(cfg_plot.eps_x), eps_x = cfg_plot.eps_x; end
        if isfield(cfg_plot,'eps_v') && ~isempty(cfg_plot.eps_v), eps_v = cfg_plot.eps_v; end
    end

    X = []; V = [];
    if isstruct(logdata)
        if isfield(logdata,'x'), X = logdata.x; end
        if isfield(logdata,'v'), V = logdata.v; end
    end
    if isempty(X) && isstruct(res)
        if isfield(res,'x'), X = res.x; end
        if isfield(res,'v'), V = res.v; end
    end

    if ~isempty(X) && ~isempty(V) && isstruct(cfg) && isfield(cfg,'desired_gaps') && ~isempty(cfg.desired_gaps)
        Nf = size(X,2) - 1;
        gaps = cfg.desired_gaps(:).';
        if numel(gaps) ~= Nf

            gaps = gaps(1:min(numel(gaps), Nf));
            gaps = [gaps, repmat(gaps(end), 1, max(0, Nf - numel(gaps)))];
        end
        Epos = abs(X(:,2:end) - X(:,1) - repmat(gaps, size(X,1), 1)) <= eps_x;
        Evel = abs(V(:,2:end) - V(:,1)) <= eps_v;
        cv = mean(Epos & Evel, 2);
        return;
    end


    T = 0;
    if isstruct(logdata) && isfield(logdata,'t') && ~isempty(logdata.t), T = numel(logdata.t); end
    if T == 0 && isstruct(res) && isfield(res,'t') && ~isempty(res.t),   T = numel(res.t); end
    if T == 0, T = 1; end
    cv = NaN(T,1);
end
