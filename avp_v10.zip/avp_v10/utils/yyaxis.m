function yyaxis(side)







    if nargin < 1 || isempty(side)

        return;
    end

    side = lower(char(side));
    ax = gca();

    switch side
        case 'left'
            try, set(ax, 'yaxislocation', 'left'); end
        case 'right'
            try, set(ax, 'yaxislocation', 'right'); end
        otherwise

    end
end
