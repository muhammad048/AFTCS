
function run = mkdir_run(cfg, scenario)
ts = datestr(now, 'yyyymmdd_HHMMSS');
outdir = fullfile('output', sprintf('%s_%s', scenario, ts));
if ~exist(outdir, 'dir'), mkdir(outdir); end
run.outdir = outdir;


fid = fopen(fullfile(outdir, 'run_summary.txt'), 'w');
fprintf(fid, 'Scenario: %s\n', scenario);
fprintf(fid, 'N followers: %d\n', cfg.N);
fprintf(fid, 'time_end = %.2f, dt = %.3f\n', cfg.sim.time_end, cfg.sim.dt);
fprintf(fid, 'alpha=%.3f, beta=%.3f, gamma=%.3f\n', cfg.ctrl.alpha, cfg.ctrl.beta, cfg.ctrl.gamma);
fprintf(fid, 'V1=%.2f, V2=%.2f, C1=%.3f, C2=%.2f\n', cfg.carf.V1, cfg.carf.V2, cfg.carf.C1, cfg.carf.C2);
fclose(fid);
end
