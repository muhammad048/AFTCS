function h = yline(y, varargin)








    if nargin < 1
        error('yline: Y value required');
    end

    ax = gca();
    xl = xlim(ax);

    hold_state = ishold(ax);
    hold(ax, 'on');
    h = line([xl(1) xl(2)], [y y]);


    applied = false;
    if ~isempty(varargin)
        try
            set(h, varargin{:});
            applied = true;
        catch

            try
                if ischar(varargin{1})
                    set(h, 'LineStyle', varargin{1});
                end
                if numel(varargin) >= 2 && ischar(varargin{2})
                    set(h, 'DisplayName', varargin{2});
                end
                if numel(varargin) > 2
                    set(h, varargin{3:end});
                end
                applied = true;
            catch

            end
        end
    end


    if ~applied
        try
            set(h, 'LineStyle', '--');
        end
    end

    if ~hold_state, hold(ax, 'off'); end
    if nargout == 0, clear h; end
end
