function stats = log_run_summary(outdir, case_id, scenario, t, fmr, cv)















    if nargin < 6
        error('log_run_summary: need outdir, case_id, scenario, t, fmr, cv');
    end


    t   = t(:);
    fmr = fmr(:);
    cv  = cv(:);

    n = numel(t);
    if numel(fmr) ~= n || numel(cv) ~= n
        error('log_run_summary: t, fmr, cv must have the same length');
    end


    mask = ~isnan(fmr);
    stats.avg_fmr = mean(fmr(mask));
    stats.end_fmr = fmr(find(mask,1,'last'));

    mask = ~isnan(cv);
    stats.avg_cv = mean(cv(mask));
    stats.end_cv = cv(find(mask,1,'last'));


    if exist(outdir, 'dir') ~= 7


        try, mkdir(outdir); end
    end


    summary_path = fullfile(outdir, 'run_summary.txt');
    new_file = exist(summary_path, 'file') ~= 2;
    fid = fopen(summary_path, 'a');
    if fid < 0
        error('log_run_summary: cannot open file for append: %s', summary_path);
    end


    if new_file
        fprintf(fid, 'case | scenario | avg_fmr | avg_cv | end_fmr | end_cv\n');
    end

    fprintf(fid, '%s | %s | %.6f | %.6f | %.6f | %.6f\n', ...
        char(case_id), char(scenario), stats.avg_fmr, stats.avg_cv, stats.end_fmr, stats.end_cv);

    fclose(fid);
end
