function [vL, xL] = leader_profile(t, cfg)




    prof = 'paper';
    try
        if isfield(cfg,'leader') && isfield(cfg.leader,'profile') && ~isempty(cfg.leader.profile)
            prof = char(cfg.leader.profile);
        end
    end

    vL = zeros(size(t));
    for k = 1:numel(t)
        tau = t(k);

        if strcmpi(prof, 'paper')

            if tau < 30
                v = 7;
            elseif tau < 70
                v = 7 + 8/(1 + exp(-0.5*tau + 25));
            elseif tau < 80
                v = 15;
            else
                v = 15 - 15/(1 + exp(-0.5*tau + 48));
            end

            if tau >= 30
                xi = 0.3 * sin(2*pi*(tau - 30)) * exp(-(tau-30)/10);
            else
                xi = 0;
            end
            vL(k) = v + xi;
        else

            vconst = str2double(prof);
            if isnan(vconst), vconst = 7; end
            vL(k) = vconst;
        end
    end


    xL = cumtrapz(t, vL);

    try
        xL = xL + cfg.init.x(1);
    end
end

