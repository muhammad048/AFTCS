function [res, hist] = simulate_platoon(cfg)





    cfg = EnsureCfg_local(cfg, getfield_safe(cfg,'scenario','no_delay'));

    N  = cfg.N;
    hc = cfg.params.hc;
    lc = cfg.params.lc;
    alpha = cfg.ctrl.alpha;
    beta  = cfg.ctrl.beta;
    gamma = cfg.ctrl.gamma;

    dt = cfg.sim.dt;
    T  = cfg.sim.time_end;
    steps = floor(T/dt) + 1;
    t = (0:steps-1)' * dt;

    x = zeros(steps, N+1);
    v = zeros(steps, N+1);
    u = zeros(steps, N+1);
    a = zeros(steps, N+1);


    x(1,:) = cfg.init.x;
    v(1,:) = cfg.init.v;


    [vL, xL] = leader_profile(t, cfg);
    x(:,1) = xL;
    v(:,1) = vL;
    u(:,1) = 0;
    a(:,1) = 0;


    switch lower(cfg.scenario)
        case 'no_delay'
            taus = zeros(N+1,1);
        case 'homo_delay'
            taus = zeros(N+1,1);
            taus(2:end) = cfg.delay.homo;
        otherwise
            taus = cfg.delay.hetero(:);
            if numel(taus) < (N+1), taus(end+1:N+1) = 0; end
    end
    kdelay = max(0, round(taus / dt));


    log.t  = t;
    log.dt = dt;
    log.hc = hc;
    log.lc = lc;
    log.leader_idx = 1;
    log.honest_mask = true(N+1,1);
    if isfield(cfg,'fault') && isfield(cfg.fault,'ids') && ~isempty(cfg.fault.ids)
        bad = cfg.fault.ids + 1;
        bad = bad(bad>=2 & bad<=N+1);
        log.honest_mask(bad) = false;
    end
    log.faulty_msgs = zeros(steps,1);
    log.masked_msgs = zeros(steps,1);
    log.agreement   = zeros(steps,1);
    log.x = zeros(N+1, steps);
    log.v = zeros(N+1, steps);
    log.x(:,1) = x(1,:)';
    log.v(:,1) = v(1,:)';


    z_thresh  = 3.0;
    pull_frac = 0.5;

    for k = 2:steps

        kd_L = max(1, k - kdelay(1));


        x_rep_all = zeros(N,1);
        v_rep_all = zeros(N,1);
        was_fault_all = false(N,1);
        for j = 1:N
            kd_j = max(1, k - kdelay(j));
            vj_d = v(kd_j, j);
            xj_d = x(kd_j, j);

            xj_rep = xj_d; vj_rep = vj_d; was_fault = false;
            if exist('FaultUtils','class') == 8
                if FaultUtils.fault_active(cfg, k, dt) && FaultUtils.is_faulty_follower(cfg, j-1)
                    [xj_rep, vj_rep, was_fault] = FaultUtils.fault_report_random(cfg, k, j-1, xj_d, vj_d);
                end
            end
            x_rep_all(j)   = xj_rep;
            v_rep_all(j)   = vj_rep;
            was_fault_all(j) = was_fault;
        end


        [mu_x_in, out_x] = rbc_inlier_mean(x_rep_all, z_thresh);
        [mu_v_in, out_v] = rbc_inlier_mean(v_rep_all, z_thresh);


        for i = 2:N+1
            j = i-1;

            vL_d = v(kd_L, 1);


            xj_rep = x_rep_all(j);
            vj_rep = v_rep_all(j);


            xj_use0 = xj_rep; vj_use0 = vj_rep; was_masked = false;
            if exist('FaultUtils','class') == 8
                [xj_use0, vj_use0, was_masked] = FaultUtils.mask_plausibility( ...
                    cfg, k, i-1, j-1, xj_rep, vj_rep, x(k-1,i), v(k-1,i));
            end
            if was_masked, log.masked_msgs(k) = log.masked_msgs(k) + 1; end


            if was_fault_all(j), log.faulty_msgs(k) = log.faulty_msgs(k) + 1; end


            xj_use = xj_use0;
            vj_use = vj_use0;
            if out_x(j), xj_use = xj_use0 + pull_frac*(mu_x_in - xj_use0); end
            if out_v(j), vj_use = vj_use0 + pull_frac*(mu_v_in - vj_use0); end


            hij = (xj_use - x(k-1,i) - (i-j)*lc)/(i-j);
            Vi  = cfg.V.V1 + cfg.V.V2 * tanh(cfg.V.C1 * hij - cfg.V.C2);


            term_cf = alpha * (Vi - v(k-1,i));
            term_vp = beta  * (vj_use - v(k-1,i));
            term_xp = gamma * (xj_use - x(k-1,i) + vL_d * taus(i) - (lc + hc));
            term_vL = beta  * (vL_d - v(k-1,i));
            term_xL = gamma * (xL(kd_L) + vL_d * taus(i) - x(k-1,i) - (i-1)*(lc+hc));

            ui = term_cf + term_vp + term_xp + term_vL + term_xL;
            a(k,i) = ui;
            v(k,i) = v(k-1,i) + dt * a(k,i);
            x(k,i) = x(k-1,i) + dt * v(k,i);
        end


        log.x(:,k) = x(k,:)';
        log.v(:,k) = v(k,:)';


        honestFollowers = find(log.honest_mask(:));
        honestFollowers = honestFollowers(honestFollowers >= 2);
        if ~isempty(honestFollowers)
            ok_count = 0;
            for ii = 1:numel(honestFollowers)
                i_idx = honestFollowers(ii);
                pred  = i_idx - 1;
                se    = x(k, pred) - x(k, i_idx) - hc;
                ve    = v(k, i_idx) - v(k, 1);
                if abs(se) <= 1.0 && abs(ve) <= 0.5
                    ok_count = ok_count + 1;
                end
            end
            log.agreement(k) = ok_count / numel(honestFollowers);
        else
            log.agreement(k) = 1.0;
        end
    end


    res.t = t;
    res.x = x;
    res.v = v;
    res.u = u;
    res.a = a;
    res.vL = v(:,1);
    res.xL = x(:,1);
    res.log = log;
    hist = log;
end





function val = getfield_safe(s, f, def)
    if isstruct(s) && isfield(s,f) && ~isempty(s.(f))
        val = s.(f);
    else
        val = def;
    end
end

function cfg = EnsureCfg_local(cfg, scenario)

    if nargin < 2 || isempty(scenario), scenario = 'no_delay'; end
    cfg.scenario = scenario;


    if ~isfield(cfg,'N') || isempty(cfg.N)
        if isfield(cfg,'init') && isfield(cfg.init,'x')
            cfg.N = numel(cfg.init.x) - 1;
        else
            cfg.N = 9;
        end
    end


    if ~isfield(cfg,'params') || ~isstruct(cfg.params), cfg.params = struct; end
    if ~isfield(cfg.params,'lc') || isempty(cfg.params.lc), cfg.params.lc = 5; end
    if ~isfield(cfg.params,'hc') || isempty(cfg.params.hc), cfg.params.hc = 5; end


    if ~isfield(cfg,'ctrl') || ~isstruct(cfg.ctrl), cfg.ctrl = struct; end
    if ~isfield(cfg.ctrl,'alpha') || isempty(cfg.ctrl.alpha), cfg.ctrl.alpha = 3.5; end
    if ~isfield(cfg.ctrl,'beta')  || isempty(cfg.ctrl.beta),  cfg.ctrl.beta  = 0.1;  end
    if ~isfield(cfg.ctrl,'gamma') || isempty(cfg.ctrl.gamma), cfg.ctrl.gamma = 0.52; end


    if ~isfield(cfg,'V') || ~isstruct(cfg.V), cfg.V = struct; end
    if ~isfield(cfg.V,'V1') || isempty(cfg.V.V1), cfg.V.V1 = 6.75; end
    if ~isfield(cfg.V,'V2') || isempty(cfg.V.V2), cfg.V.V2 = 7.91; end
    if ~isfield(cfg.V,'C1') || isempty(cfg.V.C1), cfg.V.C1 = 0.13; end
    if ~isfield(cfg.V,'C2') || isempty(cfg.V.C2), cfg.V.C2 = 1.59; end


    if ~isfield(cfg,'sim') || ~isstruct(cfg.sim), cfg.sim = struct; end
    if ~isfield(cfg.sim,'dt') || isempty(cfg.sim.dt), cfg.sim.dt = 0.01; end
    if ~isfield(cfg.sim,'time_end') || isempty(cfg.sim.time_end), cfg.sim.time_end = 120; end


    if ~isfield(cfg,'init') || ~isstruct(cfg.init), cfg.init = struct; end
    if ~isfield(cfg.init,'x') || isempty(cfg.init.x)
        cfg.init.x = [0,10,20.5,31.5,43,55,67.5,80.5,94,108];
    end
    if ~isfield(cfg.init,'v') || isempty(cfg.init.v)
        cfg.init.v = 7*ones(1, numel(cfg.init.x));
    end
    L = min([numel(cfg.init.x), numel(cfg.init.v), cfg.N+1]);
    cfg.init.x = cfg.init.x(1:L);
    cfg.init.v = cfg.init.v(1:L);
    cfg.N = L - 1;


    if ~isfield(cfg,'leader'), cfg.leader = struct; end


    if ~isfield(cfg,'delay') || ~isstruct(cfg.delay), cfg.delay = struct; end

    hetero = [];
    cand = {'hetero','heterogeneous','tau','taus','tau_vec','delay_vec','delay_hetero'};
    for k = 1:numel(cand)
        if isfield(cfg.delay, cand{k}) && ~isempty(cfg.delay.(cand{k}))
            hetero = cfg.delay.(cand{k});
            break;
        elseif isfield(cfg, cand{k}) && ~isempty(cfg.(cand{k}))
            hetero = cfg.(cand{k});
            break;
        end
    end
    if isempty(hetero)
        hetero = [0, 0.15,0.18,0.19,0.20,0.21,0.22,0.23,0.27,0.30];
    end
    hetero = hetero(:).';
    if numel(hetero) < (cfg.N+1)
        hetero = [hetero, zeros(1, cfg.N+1-numel(hetero))];
    end
    cfg.delay.hetero = hetero(1:(cfg.N+1));

    if ~isfield(cfg.delay,'homo') || isempty(cfg.delay.homo)
        homo = [];
        hcands = {'homo','homogeneous','tau_homo','delay_homo'};
        for k = 1:numel(hcands)
            if isfield(cfg.delay,hcands{k}) && ~isempty(cfg.delay.(hcands{k}))
                homo = cfg.delay.(hcands{k});
                break;
            elseif isfield(cfg,hcands{k}) && ~isempty(cfg.(hcands{k}))
                homo = cfg.(hcands{k});
                break;
            end
        end
        if isempty(homo), homo = 0.20; end
        cfg.delay.homo = homo;
    end

    ok = any(strcmpi(cfg.scenario, {'no_delay','homo_delay','hetero_delay'}));
    if ~ok, cfg.scenario = 'no_delay'; end
end


function [mu_in, is_outlier] = rbc_inlier_mean(vec, z_thresh)
    vec = vec(:);
    if isempty(vec), mu_in = NaN; is_outlier = false(size(vec)); return; end
    med  = median(vec);
    madv = median(abs(vec - med));
    if madv <= 0, mu_in = med; is_outlier = false(size(vec)); return; end
    rz = 0.6745 * abs(vec - med) / madv;
    is_outlier = (rz > z_thresh);
    if any(~is_outlier), mu_in = mean(vec(~is_outlier)); else, mu_in = med; end
end

