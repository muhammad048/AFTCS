
function main()

clc; close all; clear;


addpath('utils');
addpath('plotting');

xlsxPath      = 'data/platoon_dataset.xlsx';
scenarios     = {'no_delay','homo_delay','hetero_delay'};
faultCases    = [0 1 2 3];
faultStart    = 30.0;
saveMatlabFig = false;


summary_logs  = {};
summary_cases = {};
avg_rows      = {};


if ~exist('output','dir'),  mkdir('output');  end
if ~exist('results','dir'), mkdir('results'); end

for fc = 1:numel(faultCases)
    nFaulty = faultCases(fc);

    for s = 1:numel(scenarios)
        scenario = scenarios{s};
        fprintf('\n=== Case: %d faulty | Scenario: %s ===\n', nFaulty, scenario);

        try



            cfg = load_dataset(xlsxPath, scenario);
            cfg.scenario = scenario;




            if ~isfield(cfg,'fault') || ~isstruct(cfg.fault), cfg.fault = struct; end
            cfg.fault.enable     = nFaulty > 0;
            cfg.fault.count      = nFaulty;
            N_guess = guessN(cfg);
            cfg.fault.num_faulty = min(nFaulty, cfg.N);
            cfg.fault.start_time = faultStart;
            cfg.fault.seed       = 1234 + 100*fc + s;


            if ~isfield(cfg.fault,'params') || ~isstruct(cfg.fault.params), cfg.fault.params = struct; end
            cfg.fault.params = setdefault(cfg.fault.params, 'sigma_x',    50.0);
            cfg.fault.params = setdefault(cfg.fault.params, 'sigma_v',     5.0);
            cfg.fault.params = setdefault(cfg.fault.params, 'p_fullrand',  0.25);
            cfg.fault.params = setdefault(cfg.fault.params, 'v_min',       0.0);
            cfg.fault.params = setdefault(cfg.fault.params, 'v_max',      40.0);
            cfg.fault.params = setdefault(cfg.fault.params, 'x_span',    300.0);


            rng(cfg.fault.seed);
            if cfg.fault.enable && cfg.fault.num_faulty > 0
                ids = sort(randperm(N_guess, cfg.fault.num_faulty));
                cfg.fault.ids = ids;
            else
                cfg.fault.ids = [];
            end




            run_tag = sprintf('case%d_%s', nFaulty, scenario);
            runInfo = mkdir_run(cfg, run_tag);
            outdir  = runInfo.outdir;




            [res, hist] = simulate_platoon(cfg);




            met = compute_metrics(cfg, res);
            safe_plot(@() plot_position(      cfg, res,        outdir, scenario), saveMatlabFig);
            safe_plot(@() plot_spacing_error( cfg, res,  met,  outdir, scenario), saveMatlabFig);
            safe_plot(@() plot_velocity(      cfg, res,        outdir, scenario), saveMatlabFig);
            safe_plot(@() plot_velocity_error(cfg, res,  met,  outdir, scenario), saveMatlabFig);
            safe_plot(@() plot_acceleration(  cfg, res,  met,  outdir, scenario), saveMatlabFig);




            fault_dir = fullfile(outdir, 'fault_tolerance');
            if ~exist(fault_dir, 'dir'), mkdir(fault_dir); end

            logdata = [];
            if isstruct(res) && isfield(res,'log'), logdata = res.log; end
            if isempty(logdata) && exist('hist','var') && isstruct(hist), logdata = hist; end

            if ~isempty(logdata) && isstruct(logdata)

                if isfield(logdata,'t') && numel(logdata.t)>1
                    cfg_plot.dt = logdata.t(2) - logdata.t(1);
                else
                    cfg_plot.dt = get_nested(cfg, {'sim','dt'}, 0.01);
                end
                cfg_plot.win_s = 2.0;
                cfg_plot.eps_v = 0.5;
                cfg_plot.eps_x = 1.0;
                tag = sprintf('f%d_%s', nFaulty, scenario);

                if isfield(logdata,'masked_msgs') && isfield(logdata,'faulty_msgs')
                    safe_plot(@() plot_fault_masking_rate(logdata, cfg_plot, fault_dir, tag), saveMatlabFig);
                end
                if isfield(logdata,'x') && isfield(logdata,'v')
                    safe_plot(@() plot_consensus_validity(logdata, cfg_plot, fault_dir, tag), saveMatlabFig);
                end



                fmr_series = [];
                if isfield(logdata,'masked_msgs') && isfield(logdata,'faulty_msgs')
                    masked = double(logdata.masked_msgs(:));
                    faulty = double(logdata.faulty_msgs(:));
                    fmr_series = masked ./ faulty;
                    fmr_series(faulty==0) = NaN;
                    fmr_series = min(max(fmr_series,0),1);
                end


                cv_series = [];
                if isfield(logdata,'agreement') && ~isempty(logdata.agreement)
                    cv_series = logdata.agreement(:);
                elseif exist('met','var') && isstruct(met)
                    if isfield(met,'agreement') && ~isempty(met.agreement)
                        cv_series = met.agreement(:);
                    elseif isfield(met,'cv') && ~isempty(met.cv)
                        cv_series = met.cv(:);
                    elseif isfield(met,'consensus_validity') && ~isempty(met.consensus_validity)
                        cv_series = met.consensus_validity(:);
                    end
                end
                if isempty(cv_series) && isfield(logdata,'x') && isfield(logdata,'v') && isfield(cfg,'desired_gaps') && ~isempty(cfg.desired_gaps)
                    eps_x = cfg_plot.eps_x; eps_v = cfg_plot.eps_v;
                    X = logdata.x; V = logdata.v;
                    gaps = cfg.desired_gaps(:).';
                    Epos = abs(X(:,2:end) - X(:,1) - repmat(gaps, size(X,1),1)) <= eps_x;
                    Evel = abs(V(:,2:end) - V(:,1)) <= eps_v;
                    cv_series = mean(Epos & Evel, 2);
                end



                if isempty(fmr_series)
                    avg_fmr = 0;
                else
                    tf = fmr_series(:);
                    tf = tf(~isnan(tf));
                    if isempty(tf), avg_fmr = 0; else, avg_fmr = mean(tf); end
                end


                if isempty(cv_series)
                    avg_cv = 0;
                else
                    tc = cv_series(:);
                    tc = tc(~isnan(tc));
                    if isempty(tc), avg_cv = 0; else, avg_cv = mean(tc); end
                end

                avg_rows(end+1,:) = {sprintf('case%d', nFaulty), scenario, avg_fmr, avg_cv};


                if isfield(logdata,'faulty_msgs') && isfield(logdata,'masked_msgs')
                    final_agree = NaN; t95 = NaN;
                    if ~isempty(cv_series)
                        final_agree = cv_series(end);
                        idx95 = find(cv_series >= 0.95, 1, 'first');
                        if ~isempty(idx95)
                            if isfield(logdata,'t') && numel(logdata.t) >= idx95
                                t95 = logdata.t(idx95);
                            else
                                t95 = (idx95-1) * cfg_plot.dt;
                            end
                        end
                    end
                    summary_logs{end+1} = struct( ...
                        'masked_msgs', logdata.masked_msgs, ...
                        'faulty_msgs', logdata.faulty_msgs, ...
                        'final_agreement', final_agree, ...
                        'time_to_95', t95 ...
                    );
                    summary_cases{end+1} = tag;
                end
            else
                warning('No structured logdata available for fault-tolerance plots (case=%d, scenario=%s)', nFaulty, scenario);
            end




            save(fullfile(outdir, 'results.mat'), 'cfg', 'res', 'met', 'hist');
            fprintf('✔ Saved: %s\n', outdir);

        catch ME
            warning('Failed (case=%d, scenario=%s): %s', nFaulty, scenario, ME.message);
        end
    end
end




if ~isempty(summary_logs)
    summary_dir = fullfile('results','fault_tolerance_summary');
    if ~exist(summary_dir,'dir'), mkdir(summary_dir); end
    write_fault_summary(summary_logs, summary_dir, summary_cases);
    fprintf('✔ Wrote summary to %s\n', summary_dir);
end




if ~isempty(avg_rows)
    summary_dir = fullfile('results','fault_tolerance_summary');
    if ~exist(summary_dir,'dir'), mkdir(summary_dir); end
    fp = fopen(fullfile(summary_dir,'avg_fmr_cv_summary.txt'), 'w');
    fprintf(fp, 'case | scenario | avg_fmr | avg_cv\n');
    for i = 1:size(avg_rows,1)
        fprintf(fp, '%s | %s | %.6f | %.6f\n', avg_rows{i,1}, avg_rows{i,2}, avg_rows{i,3}, avg_rows{i,4});
    end
    fclose(fp);
    fprintf('✔ Wrote averages to %s\n', fullfile(summary_dir,'avg_fmr_cv_summary.txt'));
end

fprintf('\nAll fault cases and scenarios processed.\n');
end


function s = setdefault(s, key, val)
    if ~isfield(s, key) || isempty(s.(key)), s.(key) = val; end
end

function val = get_nested(s, keys, def)
    val = def;
    try
        cur = s;
        for i = 1:numel(keys)
            if ~isstruct(cur) || ~isfield(cur, keys{i})
                return;
            end
            cur = cur.(keys{i});
        end
        if ~isempty(cur), val = cur; end
    catch
        val = def;
    end
end

function N = guessN(cfg)

    if isfield(cfg,'N') && ~isempty(cfg.N)
        N = cfg.N;
    elseif isfield(cfg,'init') && isfield(cfg.init,'x') && ~isempty(cfg.init.x)
        N = numel(cfg.init.x) - 1;
    else
        N = 9;
    end
end

function safe_plot(fh, saveFigAlso)

    try
        fh();
        if saveFigAlso
            h = gcf;
            if ~isempty(h) && ishghandle(h)
                fpath = get(h, 'FileName');
                if ~isempty(fpath)
                    [p,n,~] = fileparts(fpath);
                    savefig(h, fullfile(p, [n '.fig']));
                end
            end
        end
        drawnow;
    catch ME
        warning('Plot failed: %s', ME.message);
    end
end
